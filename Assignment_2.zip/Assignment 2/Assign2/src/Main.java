import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JFrame implements ActionListener {
    JLabel Display;
    JLabel Screen;

    public Main() {
        super("Machine Project: Cash Register");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setLayout(new FlowLayout());
        Keyboard();
        initScreen();
        setSize(1000, 300);
        setVisible(true);
    }

    public static void main(String[] args) {
        Main app = new Main();
    }

    public void Keyboard() {
        JTextField Screen;

        Screen = new JTextField();
        Screen.setColumns(20);
        Screen.setHorizontalAlignment(JTextField.RIGHT);
        add(Screen);
    }

    public void initScreen() {


    }

    {
        JLabel lblTitle;
        lblTitle = new JLabel("Quantity: ");
        add(lblTitle);

        JTextField tfName;
        tfName = new JTextField();
        tfName.setColumns(10);
        tfName.setHorizontalAlignment(JTextField.LEFT);
        add(tfName);

        JButton btnEnter;
        btnEnter = new JButton("Enter");
        add(btnEnter);
        btnEnter.addActionListener(this);

        JPanel panel = new JPanel(new BorderLayout());
        add(panel);
    }

    {
        JLabel lblTitle;
        lblTitle = new JLabel("Cash: ");
        add(lblTitle);

        JTextField tfName;
        tfName = new JTextField();
        tfName.setHorizontalAlignment(JTextField.LEFT);
        tfName.setColumns(10);
        add(tfName);

        JButton btnEnter;
        btnEnter = new JButton("Enter");
        add(btnEnter);
        btnEnter.addActionListener(this);

        JPanel panel = new JPanel(new BorderLayout());
        add(panel);
        {
            JButton btn;
            btn = new JButton("Barcode: 1236423");
            btn.addActionListener(this);
            panel.add(btn, BorderLayout.WEST);

            btn = new JButton("Barcode: 1236426");
            btn.addActionListener(this);
            panel.add(btn, BorderLayout.CENTER);

            Display = new JLabel();
            panel.add(Display, BorderLayout.SOUTH);
        }
    }

    public void actionPerformed(ActionEvent e) {
        JButton btn;

        if (e.getActionCommand().equals("Enter")) {
            btn = (JButton) e.getSource();
            btn.setText("Done");
        } else if (e.getActionCommand().equals("Done")) {
            btn = (JButton) e.getSource();
            btn.setText("Enter");
        } else if (e.getActionCommand().equals("Barcode: 1236423")) {
            Display.setText("Item: Apples");
            Display.setHorizontalAlignment(JLabel.LEFT);
        } else if (e.getActionCommand().equals("Barcode: 1236426")) {
            Display.setText("Item: Bananas");
            Display.setHorizontalAlignment(JLabel.RIGHT);
        }
    }

    public void keyboard() {
        JTextField lblScreen;

        lblScreen = new JTextField();
        lblScreen.setColumns(20);
        lblScreen.setHorizontalAlignment(JTextField.RIGHT);
        add(lblScreen);
    }

}

